class Calculator 
{
    static int add(int a, int b) 
	{
		return a + b; 
	}
	
    static double add(double a, double b) 
	{
		return a + b; 
	}
}
class Calmain
{
	public static void main(String [] args)
	{
		System.out.println(Calculator.add(10,5));
		System.out.println(Calculator.add(10.5,5.5));
	}
}