interface Student 
{
    int Regno = 101;         
    String NAME = "Liya";

    void displayInfo();         
}

class Detail implements Student
{
    public void displayInfo() 
	{
        System.out.println("Name:"+NAME);
        System.out.println("RegNo:" +Regno);
    }
}

public class main 
{
    public static void main(String[] args) 
	{
        Detail d= new Detail();
        d.displayInfo();
    }
}
