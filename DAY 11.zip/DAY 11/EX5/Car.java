public class Car
{
	String brand;
	int year;
	
    public Car(String brand,int year)
	{
		this.brand=brand;
		this.year=year;
	}

static void display(String x,int y)
{
    System.out.println("Brand:"+x);
	System.out.println("Year:"+y);
}
public static void main(String [] args)
{

	display("Tata",2011);
}
}