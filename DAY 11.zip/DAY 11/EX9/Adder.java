class Adder 
{
    int add(int a, int b) 
	{
        return a + b;
    }

    public static void main(String[] args)
	{
        Adder a= new Adder();
        System.out.println("Addison: " + a.add(5,10));
    }
}
