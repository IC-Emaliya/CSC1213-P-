class Default
 {
    int n;
    String s;
	double a;

    public static void main(String[] args)
	{
        Default d = new Default();
        System.out.println("int: " + d.n + ", String: " + d.s+ ",Double: " +d.a);
    }
}