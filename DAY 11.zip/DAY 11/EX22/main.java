class Animal 
{
    void sound() 
	{ 
	   System.out.println("Animal Makes sound"); 
	}
}

class Dog extends Animal 
{
    void sound() 
	{ 
	   System.out.println("Bark"); 
	}
}

class main 
{
    public static void main(String[] args) 
	{
        Animal a = new Dog();
        a.sound();  
    }
}
