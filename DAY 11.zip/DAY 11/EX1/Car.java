public class Car{
	String brand;
    double speed;
public static void main(String [] args)
{
	Car c=new Car();
	c.brand="TATA";
	c.speed=120;
	System.out.println("My "+c.brand+" is "+c.speed);
}
}

	
	