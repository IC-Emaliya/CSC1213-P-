class Animal 
{
    void display() 
	{ 
	   System.out.println("Animal"); 
	}
}

class Dog extends A 
{
    void display() 
	{ 
	   System.out.println("Dog"); 
	}
}

class main
{
    public static void main(String[] args) 
	{
        Dog d=new Dog();
		d.display();
    }
}
