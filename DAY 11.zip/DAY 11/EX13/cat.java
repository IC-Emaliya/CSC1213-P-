class Animal 
{
    Animal() 
	{
        System.out.println("Animal make sound");
    }
}

class cat extends Animal 
{
    cat() 
	{
        super(); 
        System.out.println("Meow..");
    }

    public static void main(String[] args)
	{
        cat c = new cat();
    }
}
