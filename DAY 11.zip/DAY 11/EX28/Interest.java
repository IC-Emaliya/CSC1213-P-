abstract class Bank {
    abstract double getInterestRate();
}

class SBI extends Bank {
    double getInterestRate() 
	{
        return 10; 
    }
}

public class Interest 
{
    public static void main(String[] args) 
	{
        Bank b = new SBI();  
        System.out.println("SBI Interest Rate: " + b.getInterestRate() + "%");
    }
}
