interface Flyable 
{
    void fly();  
}

class Bird implements Flyable 
{
  
    public void fly() 
	{
        System.out.println("Birds are Flying");
    }
}

public class main 
{
    public static void main(String[] args) 
	{
        Flyable f = new Bird(); 
        f.fly(); 
    }
}