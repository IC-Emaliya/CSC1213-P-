class Shape 
{
    double area() 
	{
		return 0; 
    }
}

class Circle extends Shape 
{
    double radius = 7;

    double area() 
	{
        return Math.PI * radius * radius;
    }
}

class Square extends Shape {
    double Length = 6;

    double area() 
	{
        return Length * Length;
    }
}
class shapemain
{
	public static void main(String [] args)
	{
		Circle c=new Circle();
		System.out.println("Circle area is:"+c.area());
		Square s=new Square();
		System.out.println("Square area is:"+s.area());
	}
}
