class Student 
{
    void printDetails() 
	{
        System.out.println("Liya_01");
    }
}

class NewStudent extends Student 
{
    void printDetails() 
	{
        System.out.println("Carththarina_02");
    }
}
class studentmain
{
	public static void main (String [] args)
	{
		NewStudent n=new NewStudent();
		n.printDetails();
	}
}
