class Vehicle 
{
    void speed() 
	{
        System.out.println("Vehicle speed is 120 km/h");
    }
}

class Car extends Vehicle 
{
    void colour() 
	{
        System.out.println("Car is black colour");
    }

    public static void main(String[] args)
	{
        Car c = new Car();
        c.speed(); 
        c.colour();  
    }
}
