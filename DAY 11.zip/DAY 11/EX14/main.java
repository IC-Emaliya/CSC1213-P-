class Animal
{
	void eat()
	{
		System.out.println("Animals eating");
	}
}
class Dog extends Animal
{
	void bark()
	{
		super.eat();
		System.out.println("Bow bow");
	}
}
class main
{
	public static void main(String [] args)
	{
		Dog d=new Dog();
		d.bark();
	}
}