class A 
{
    void display() 
	{
        System.out.println("This is A");
    }
}

class B extends A 
{
    public static void main(String[] args)
	{
        B b = new B();
        b.display();
    }
}
