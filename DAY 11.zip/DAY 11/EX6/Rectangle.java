public class Rectangle
{
	int Length;
	int width;
	
	public int calculate_area(int Length,int width)
	{
		int area=Length*width;
		return area;
	}
	public static void main(String[] args)
	{
		Rectangle r=new Rectangle();
		System.out.println(r.calculate_area(5,6));
	}
}
	