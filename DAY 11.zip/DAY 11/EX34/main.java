class Animal 
{
    void eat() 
	{
        System.out.println("Animal eats food");
    }
}

interface First 
{
    void run();
}

interface Second 
{
    void bark();
}


class Dog extends Animal implements First,Second
{
    public void run() 
	{
        System.out.println("Dog runs ");
    }

   
    public void bark() 
	{
        System.out.println("Dog barks");
    }
}

public class main 
{
    public static void main(String[] args) 
	{
        Dog d = new Dog();
        d.eat();    
        d.run();    
        d.bark(); 
    }
}
