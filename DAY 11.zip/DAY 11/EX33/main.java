abstract class Vehicle 
{
    abstract void race();

    void run() 
	{
        System.out.println("Vehicle is running");
    }
}

class Bike extends Vehicle 
{
    void race() 
	{
        System.out.println("Bike racing");
    }
}

public class main 
{
    public static void main(String[] args) 
	{
        // Vehicle v = new Vehicle(); - Error: Cannot instantiate the type Vehicle

        Vehicle b = new Bike(); 
        b.race();               
        b.run();                
    }
}
