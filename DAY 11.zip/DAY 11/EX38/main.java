class Numbers{
    
    static int num=10;
	
    static void display() 
	{
        System.out.println("Numbers");
    }
}

public class main 
{
    public static void main(String[] args) 
	{
     
        System.out.println("Static variable: " +Numbers.num);
        Numbers.display();
    }
}
