class Animal 
{
    void sound() 
	{
        System.out.println("Animal make sound");
    }
}

class cat extends Animal 
{
    void sound() 
	{ 
        System.out.println("Meow..");
    }

    public static void main(String[] args)
	{
        cat c = new cat();
		c.sound();
    }
}