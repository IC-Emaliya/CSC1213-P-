class ObjectCounter 
{
    static int count = 0; 

    
    ObjectCounter() 
	{
        count++;
        System.out.println("Object created. Current count: "+ count);
    }
}

public class main 
{
    public static void main(String[] args) 
	{
        ObjectCounter obj1 = new ObjectCounter();
        ObjectCounter obj2 = new ObjectCounter();
       
	    System.out.println("Total objects created: " + ObjectCounter.count);
    }
}
