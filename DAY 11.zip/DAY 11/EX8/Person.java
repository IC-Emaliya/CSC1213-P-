class Person {
    private String name;

    public void setter(String n) 
	{
        name = n;
    }

    public String getter() 
	{
        return name;
    }
	
	public static void main(String [] args)
	{
		Person p=new Person();
		p.setter("Liya");
		System.out.println(p.getter());
	}
}
