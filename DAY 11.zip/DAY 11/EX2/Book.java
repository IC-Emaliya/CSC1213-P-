public class Book{
	
	String Title;
	String author;
	
	public Book(String Title,String author)
	{
		this.Title=Title;
		this.author=author;
	}
	public static void main(String [] args)
	{
		Book b=new Book("Statics","Lee");
		System.out.println(b.Title+"-"+b.author);
	}
}	
		
		