public class Student
{
	int Regno;
	int Age;
	int Marks;
	
	public Student(int Regno,int Age,int Marks)
	{
		this.Regno=Regno;
		this.Age=Age;
		this.Marks=Marks;
	}
	public  Student(int Regno,int Age)
	{
		this.Regno=Regno;
		this.Age=Age;
	}
	public static void main(String [] args)
	{
		Student s1=new Student(01,22,85);
		Student s2=new Student(02,22);
		System.out.println(s1.Regno+"-"+s1.Age+"-"+s1.Marks);
		System.out.println(s2.Regno+"-"+s2.Age);
	}
}

		
		