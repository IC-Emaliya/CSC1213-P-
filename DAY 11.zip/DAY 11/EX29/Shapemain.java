abstract class Shape 
{
    abstract void display(); 
}


class Rectangle extends Shape 
{
    void display() 
	{
        System.out.println("rectangle");
    }
}

public class Shapemain
{
    public static void main(String[] args) 
	{
        Shape s = new Rectangle(); 
        s.display(); 
    }
}
