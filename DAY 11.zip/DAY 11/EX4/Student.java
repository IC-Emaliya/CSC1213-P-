public class Student{
	
	String Name;
	String City;
	
	public Student(String Name,String City)
	{
		this.Name=Name;
		this.City=City;
	}
	public static void main(String [] args)
	{
		Student s=new Student("Liya","Vavuniya");
		System.out.println(s.Name+"-"+s.City);
	}
}	