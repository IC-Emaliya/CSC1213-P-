class Numbers
{
    private int x = 5;
    public int y = 10;
    protected int z = 15;

    public void display() 
	{
        System.out.println("Numbers class");
        System.out.println("private = " +x);
        System.out.println("public = " +y);
        System.out.println("protected = " +z);
    }
}

public class main 
{
    public static void main(String[] args) {
        Numbers n=new Numbers();

        // System.out.println("private = " + n.x); // Error: privateVar has private access
		
        System.out.println("public = " + n.y);  
        System.out.println("protectedVar = " + n.z);

        n.display();
    }
}
