class Animal 
{
    void eat() 
	{ 
	    System.out.println("Animals Eating"); 
	}
}

class Dog extends Animal 
{
    void Bark() 
	{
		System.out.println("Bow bow"); 
	}
}

class BabyDog extends Dog 
{
    void Run() 
	{ 
	    System.out.println("running");
	}
}
class main
{
	public static void main(String [] args)
	{
		BabyDog b=new BabyDog();
		b.Run();
		b.Bark();
		b.eat();
	}
}
