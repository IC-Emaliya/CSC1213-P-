class Animal 
{
    final void Eat() 
	{
        System.out.println("Animals are eating");
    }
}

// Trying to override this method will cause a compile-time error
class Dog extends Animal 
{
    // void Bark() {
    //     System.out.println("Bow Bow");}
    
}

public class Finalmain {
    public static void main(String[] args) 
	{
        Dog d = new Dog();
        d.Eat(); 
    }
}
