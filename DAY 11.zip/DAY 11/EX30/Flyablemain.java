interface Flyable 
{
    void fly();  
}

class Bird implements Flyable 
{
  
    public void fly() 
	{
        System.out.println("Birda are Flying");
    }
}

public class Flyablemain 
{
    public static void main(String[] args) 
	{
        Flyable f = new Bird(); 
        f.fly(); 
    }
}
