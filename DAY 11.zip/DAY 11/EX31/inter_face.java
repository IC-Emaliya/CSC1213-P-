interface Printable 
{
    void print();
}

interface Scannable 
{
    void scan();
}

class Printer implements Printable, Scannable 
{
    public void print() 
	{
        System.out.println("Printing document...");
    }


    public void scan() 
	{
        System.out.println("Scanning document...");
    }
}

public class inter_face
{
    public static void main(String[] args) 
	{
        Printer p = new Printer();
        p.print();  
        p.scan();   
    }
}
