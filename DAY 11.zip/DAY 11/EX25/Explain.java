// Method Overloading Example
class Calculator 
{
   
    int add(int a, int b) 
	{
        return a + b;
    }

    double add(double a, double b) 
	{
        return a + b;
    }
}

// Method Overriding Example
class Animal 
{
    void sound() 
	{
        System.out.println("Animal makes sound");
    }
}

class Dog extends Animal 
{
    void sound() 
	{
        System.out.println("Bow bow");
    }
}

public class Explain 
{
    public static void main(String[] args) 
	{
        Calculator c = new Calculator();
        System.out.println("int add: " + c.add(2, 3));           
        System.out.println("double add: " + c.add(2.5, 3.5));    

    
        Animal a = new Animal();
        a.sound();
        Dog d=new Dog();
		d.sound();
    }
}
