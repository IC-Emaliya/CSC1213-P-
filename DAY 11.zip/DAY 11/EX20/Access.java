

class Modifiers
{
    private void privateMethod() 
	{
        System.out.println("Private method ");
    }

    void defaultMethod() 
	{
        System.out.println("Default method");
    }

    protected void protectedMethod() 
	{
        System.out.println("Protected method");
    }

    public void publicMethod() 
	{
        System.out.println("Public method");
    }

}  
class Modifiers2 extends Modifiers 
{
    public void show() 
	{
        // privateMethod(); // Not accessible - compile-time error
        // defaultMethod(); //Accessible if in same package
        protectedMethod(); // Accessible - protected allows access in subclass
        publicMethod();    // Accessible
    }
}

public class Access 
{
    public static void main(String[] args) {
        Modifiers2 m = new Modifiers2();
        m.show();
    }
}
